package dao;

import model.Objectif;
import utils.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ObjectifDAO {

    public static List<Objectif> getObjectifsByUser(int userId) throws SQLException {
        List<Objectif> objectifs = new ArrayList<>();
        String query = "SELECT * FROM objectifs WHERE user_id = ?";
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, userId);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    Objectif objectif = new Objectif(
                        rs.getString("title"),
                        rs.getString("priority"),
                        rs.getString("status"),
                        rs.getDate("start_date"),
                        rs.getDate("end_date"),
                        rs.getInt("user_id") 
                    );
                    objectif.setId(rs.getInt("id"));
                    objectifs.add(objectif);
                }
            }
        }
        return objectifs;
    }

    public static void addObjectif(Objectif objectif) throws SQLException {
        String query = "INSERT INTO objectifs (title, priority, status, start_date, end_date, user_id) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, objectif.getTitle());
            preparedStatement.setString(2, objectif.getPriority());
            preparedStatement.setString(3, objectif.getStatus());
            preparedStatement.setDate(4, objectif.getStartDate());
            preparedStatement.setDate(5, objectif.getEndDate());
            preparedStatement.setInt(6, objectif.getUserId());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Inserting objectif failed, no rows affected.");
            }
        }
    }

    public static void deleteObjectif(int id) throws SQLException {
        String query = "DELETE FROM objectifs WHERE id = ?";
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
             
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        }
    }

    public static void updateObjectif(Objectif objectif) throws SQLException {
        String query = "UPDATE objectifs SET title = ?, priority = ?, status = ?, start_date = ?, end_date = ? WHERE id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, objectif.getTitle());
            preparedStatement.setString(2, objectif.getPriority());
            preparedStatement.setString(3, objectif.getStatus());
            preparedStatement.setDate(4, objectif.getStartDate());
            preparedStatement.setDate(5, objectif.getEndDate());
            preparedStatement.setInt(6, objectif.getId());

            preparedStatement.executeUpdate();
        }
    }

    public static Objectif getObjectifById(int id) throws SQLException {
        String query = "SELECT * FROM objectifs WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return new Objectif(
                        resultSet.getString("title"),
                        resultSet.getString("priority"),
                        resultSet.getString("status"),
                        resultSet.getDate("start_date"),
                        resultSet.getDate("end_date"),
                        resultSet.getInt("user_id")  
                );
            } else {
                return null; 
            }
        }
    }
}
