package dao;

import model.Tache;
import utils.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TacheDAO {

    public static void addTache(Tache tache) {
        String sql = "INSERT INTO taches (title, priority, status, due_date, user_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, tache.getTitle());

            if (tache.getPriority() != null && isValidPriority(tache.getPriority())) {
                ps.setString(2, tache.getPriority());
            } else {
                ps.setNull(2, Types.VARCHAR);
            }

            if (tache.getStatus() != null && isValidStatus(tache.getStatus())) {
                ps.setString(3, tache.getStatus());
            } else {
                ps.setNull(3, Types.VARCHAR);
            }

            if (tache.getDueDate() != null) {
                ps.setDate(4, tache.getDueDate());
            } else {
                ps.setNull(4, Types.DATE);
            }

            ps.setInt(5, tache.getUserId());

            System.out.println("Executing SQL: " + sql);
            System.out.println("Parameters: Title=" + tache.getTitle() + ", Priority=" + tache.getPriority() +
                    ", Status=" + tache.getStatus() + ", Due Date=" + tache.getDueDate() + ", User ID=" + tache.getUserId());

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Task added successfully!");
            } else {
                System.out.println("Task insertion failed.");
            }

        } catch (SQLException e) {
            System.err.println("Error while adding task: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static List<Tache> getAllTachesByUserId(int userId) {
        List<Tache> taches = new ArrayList<>();
        String sql = "SELECT id, title, priority, status, due_date FROM taches WHERE user_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Tache tache = new Tache(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("priority"),
                            rs.getString("status"),
                            rs.getDate("due_date")
                    );
                    taches.add(tache);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error while fetching tasks by user ID: " + e.getMessage());
            e.printStackTrace();
        }

        return taches;
    }

    public static void deleteTache(int id) {
        String sql = "DELETE FROM taches WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Task deleted successfully!");
            } else {
                System.out.println("No task found with the given ID.");
            }

        } catch (SQLException e) {
            System.err.println("Error while deleting task: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void updateTache(Tache tache) {
        String sql = "UPDATE taches SET title = ?, priority = ?, status = ?, due_date = ?, user_id = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, tache.getTitle());
            ps.setString(2, tache.getPriority());
            ps.setString(3, tache.getStatus());
            ps.setDate(4, tache.getDueDate());
            ps.setInt(5, tache.getUserId());
            ps.setInt(6, tache.getId());

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Task updated successfully!");
            } else {
                System.out.println("No task found to update.");
            }

        } catch (SQLException e) {
            System.err.println("Error while updating task: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static Tache getTacheById(int id) {
        Tache tache = null;
        String sql = "SELECT id, title, priority, status, due_date FROM taches WHERE id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    tache = new Tache(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("priority"),
                            rs.getString("status"),
                            rs.getDate("due_date")
                    );
                }
            }

        } catch (SQLException e) {
            System.err.println("Error while fetching task by ID: " + e.getMessage());
            e.printStackTrace();
        }

        return tache;
    }

    private static boolean isValidPriority(String priority) {
        return List.of("Urgente", "Importante", "Moins Importante").contains(priority);
    }

    private static boolean isValidStatus(String status) {
        return List.of("À faire", "En cours", "Terminée").contains(status);
    }
}
