package model;

import java.sql.Date;

public class Tache {
    private int id;
    private String title;
    private String priority;
    private String status;
    private Date dueDate;
    private Integer userId;

    public Tache(String title, String priority, String status, Date dueDate, Integer userId) {
        this.title = title;
        this.priority = priority;
        this.status = status;
        this.dueDate = dueDate;
        this.userId = userId;
    }

    public Tache(int id, String title, String priority, String status, Date dueDate, Integer userId) {
        this.id = id;
        this.title = title;
        this.priority = priority;
        this.status = status;
        this.dueDate = dueDate;
        this.userId = userId;
    }

    public Tache(int id, String title, String priority, String status, Date dueDate) {
        this.id = id;
        this.title = title;
        this.priority = priority;
        this.status = status;
        this.dueDate = dueDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}
