package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import model.User;
import utils.DatabaseConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/views/login.jsp");
            return;
        }

        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection conn = DatabaseConnection.getConnection()) {
            String updateSQL = "UPDATE users SET username = ?, email = ?";
            boolean updatePassword = password != null && !password.isEmpty();

            if (updatePassword) {
                updateSQL += ", password = ?";
            }
            updateSQL += " WHERE id = ?";

            try (PreparedStatement stmt = conn.prepareStatement(updateSQL)) {
                stmt.setString(1, username);
                stmt.setString(2, email);

                if (updatePassword) {
                    stmt.setString(3, password);
                    stmt.setInt(4, user.getId());
                } else {
                    stmt.setInt(3, user.getId());
                }

                int rowsUpdated = stmt.executeUpdate();
                if (rowsUpdated > 0) {
                    user.setUsername(username);
                    user.setEmail(email);
                    if (updatePassword) {
                        user.setPassword(password);
                    }
                    session.setAttribute("user", user);

                    response.sendRedirect(request.getContextPath() + "/views/dashboard.jsp");
                } else {
                    request.setAttribute("errorMessage", "La mise à jour a échoué.");
                    request.getRequestDispatcher("/views/profile.jsp").forward(request, response);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Erreur de connexion à la base de données.");
            request.getRequestDispatcher("/views/profile.jsp").forward(request, response);
        }
    }
}
