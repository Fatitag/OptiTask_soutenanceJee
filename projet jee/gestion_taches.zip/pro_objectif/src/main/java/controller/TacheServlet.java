package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import model.Tache;
import model.User;
import dao.TacheDAO;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

@WebServlet("/TacheServlet")
public class TacheServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        
        User user = (User) session.getAttribute("user");
        if (user != null) {
            System.out.println("User ID: " + user.getId());
        } else {
            System.out.println("User not found in session.");
        }

        String action = request.getParameter("action");
        
        if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            Tache tache = TacheDAO.getTacheById(id);
            request.setAttribute("tache", tache);
            request.getRequestDispatcher("/views/editTache.jsp").forward(request, response);
        } else if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            TacheDAO.deleteTache(id);
            response.sendRedirect(request.getContextPath() + "/TacheServlet");
        } else {
            List<Tache> taches = TacheDAO.getAllTachesByUserId(user.getId());
            request.setAttribute("taches", taches);
            request.getRequestDispatcher("/views/taches.jsp").forward(request, response);
        }
    
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect("/views/login.jsp");
            return;
        }

        String action = request.getParameter("action");

        try {
            if ("add".equals(action)) {
                String title = request.getParameter("title");
                String priority = request.getParameter("priority");
                String status = request.getParameter("status");
                Date dueDate = Date.valueOf(request.getParameter("dueDate"));

                Tache tache = new Tache(title, priority, status, dueDate, user.getId());
                TacheDAO.addTache(tache); 

                List<Tache> taches = TacheDAO.getAllTachesByUserId(user.getId());
                request.setAttribute("taches", taches);
                request.getRequestDispatcher("/views/taches.jsp").forward(request, response);

            } else if ("edit".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                String title = request.getParameter("title");
                String priority = request.getParameter("priority");
                String status = request.getParameter("status");
                Date dueDate = Date.valueOf(request.getParameter("dueDate"));

                Tache tache = new Tache(id, title, priority, status, dueDate, user.getId());
                TacheDAO.updateTache(tache); 

                List<Tache> taches = TacheDAO.getAllTachesByUserId(user.getId());
                request.setAttribute("taches", taches);
                request.getRequestDispatcher("/views/taches.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Une erreur s'est produite: " + e.getMessage());
            request.getRequestDispatcher("/views/taches.jsp").forward(request, response);
        }
    }
}
