package controller;

import dao.UserDAO;
import model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("user") != null) {
            response.sendRedirect(request.getContextPath() + "/views/dashboard.jsp");
            return; 
        }

        request.getRequestDispatcher("/views/login.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        UserDAO userDAO = new UserDAO();
        User user = null;

        try {
            user = userDAO.getUserByEmailAndPassword(email, password); 
        } catch (SQLException e) {
            throw new ServletException("Database error during login", e);
        }

        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user); 
            response.sendRedirect(request.getContextPath() + "/views/dashboard.jsp"); 
        } else {
            response.sendRedirect(request.getContextPath() + "/views/login.jsp?error=true");
        }
    }
}
