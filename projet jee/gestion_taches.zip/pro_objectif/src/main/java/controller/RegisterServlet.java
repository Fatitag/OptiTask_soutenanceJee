package controller;

import dao.UserDAO;
import model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        if (password.equals(confirmPassword)) {
            User newUser = new User(username, email, password);

            UserDAO userDAO = new UserDAO();

            try {
                if (userDAO.getUserByUsername(username) == null) {
                    userDAO.registerUser(newUser);

                    HttpSession session = request.getSession();
                    session.setAttribute("user", newUser);

                    response.sendRedirect(request.getContextPath() + "/views/dashboard.jsp?success=true");
                } else {
                    response.sendRedirect(request.getContextPath() + "/register.jsp?error=username_taken");
                }
            } catch (SQLException e) {
                throw new ServletException("Database error during registration", e);
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/register.jsp?error=password_mismatch");
        }
    }
}
