package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.User;
import utils.DatabaseConnection;

@WebServlet("/DashboardServlet")
public class DashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user != null) {
            int userId = user.getId();

            try (Connection conn = DatabaseConnection.getConnection()) {
                String countCategoriesSQL = "SELECT COUNT(*) FROM categories WHERE user_id = ?";
                String countObjectivesSQL = "SELECT COUNT(*) FROM objectifs WHERE user_id = ?";

                try (PreparedStatement stmtCategories = conn.prepareStatement(countCategoriesSQL);
                     PreparedStatement stmtObjectives = conn.prepareStatement(countObjectivesSQL)) {

                    stmtCategories.setInt(1, userId);
                    stmtObjectives.setInt(1, userId);

                    ResultSet rsCategories = stmtCategories.executeQuery();
                    rsCategories.next();
                    int categoriesCount = rsCategories.getInt(1);

                    ResultSet rsObjectives = stmtObjectives.executeQuery();
                    rsObjectives.next();
                    int objectivesCount = rsObjectives.getInt(1);

                    request.setAttribute("categoriesCount", categoriesCount);
                    request.setAttribute("objectivesCount", objectivesCount);
                    System.out.println("Categories Count: " + categoriesCount);
                    System.out.println("Objectives Count: " + objectivesCount);

                    request.getRequestDispatcher("/views/dashboard.jsp").forward(request, response);

                } catch (SQLException e) {
                    e.printStackTrace();
                    request.setAttribute("errorMessage", "Erreur de base de données.");
                    request.getRequestDispatcher("/views/dashboard.jsp").forward(request, response);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("errorMessage", "Erreur de connexion à la base de données.");
                request.getRequestDispatcher("/views/dashboard.jsp").forward(request, response);
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/views/login.jsp");
        }
    }
}
