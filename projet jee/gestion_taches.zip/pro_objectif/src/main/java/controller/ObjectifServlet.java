package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Objectif;
import model.User;
import dao.ObjectifDAO;
import java.sql.Date;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/ObjectifServlet")
public class ObjectifServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ObjectifServlet() throws SQLException {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user != null) {
            String action = request.getParameter("action");

            if ("edit".equals(action)) {
                int objectifId = Integer.parseInt(request.getParameter("id"));
                try {
                    Objectif objectif = ObjectifDAO.getObjectifById(objectifId);
                    if (objectif != null) {
                        request.setAttribute("objectif", objectif);
                        request.getRequestDispatcher("/views/editObjectif.jsp").forward(request, response);
                    } else {
                        response.sendError(HttpServletResponse.SC_NOT_FOUND, "Objective not found.");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error fetching objective: " + e.getMessage());
                }
            }

            else if ("viewDetails".equals(action)) {
                int objectifId = Integer.parseInt(request.getParameter("id"));
                try {
                    Objectif objectif = ObjectifDAO.getObjectifById(objectifId);
                    request.setAttribute("objectif", objectif);
                    HttpSession userSession = request.getSession();
                    List<String> todoList = (List<String>) userSession.getAttribute("todoList_" + objectifId);
                    if (todoList == null) {
                        todoList = new ArrayList<>();
                    }
                    request.setAttribute("todoList", todoList);
                    request.getRequestDispatcher("/views/objectifDetails.jsp").forward(request, response);
                } catch (SQLException e) {
                    e.printStackTrace();
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error fetching objective: " + e.getMessage());
                }
            }
            else {
                try {
                    List<Objectif> objectifs = ObjectifDAO.getObjectifsByUser(user.getId());
                    request.setAttribute("objectifs", objectifs);
                    request.getRequestDispatcher("/views/objectifs.jsp").forward(request, response);
                } catch (SQLException e) {
                    e.printStackTrace();
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error fetching objectives: " + e.getMessage());
                }
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/views/login.jsp");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        String action = request.getParameter("action");

        if (user != null) {
            if ("delete".equals(action)) {
                int objectifId = Integer.parseInt(request.getParameter("id"));
                try {
                    ObjectifDAO.deleteObjectif(objectifId);
                    response.sendRedirect(request.getContextPath() + "/ObjectifServlet");
                } catch (SQLException e) {
                    e.printStackTrace();
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error occurred while deleting the objective");
                }
            } else if ("addTodo".equals(action)) {
                int objectifId = Integer.parseInt(request.getParameter("id"));
                String todoItem = request.getParameter("todoItem");
                HttpSession userSession = request.getSession();
                List<String> todoList = (List<String>) userSession.getAttribute("todoList_" + objectifId);

                if (todoList == null) {
                    todoList = new ArrayList<>();
                }

                todoList.add(todoItem);
                userSession.setAttribute("todoList_" + objectifId, todoList);

                response.sendRedirect(request.getContextPath() + "/ObjectifServlet?action=viewDetails&id=" + objectifId);
            } else if ("edit".equals(action)) {
                int objectifId = Integer.parseInt(request.getParameter("id"));
                String title = request.getParameter("title");
                String priority = request.getParameter("priority");
                String status = request.getParameter("status");

                String startDateStr = request.getParameter("startDate");
                String endDateStr = request.getParameter("endDate");

                Date startDate = null;
                Date endDate = null;

                try {
                    if (startDateStr != null && !startDateStr.isEmpty()) {
                        startDate = Date.valueOf(startDateStr);
                    }
                    if (endDateStr != null && !endDateStr.isEmpty()) {
                        endDate = Date.valueOf(endDateStr);
                    }

                    Objectif objectif = ObjectifDAO.getObjectifById(objectifId);
                    if (objectif != null) {
                        objectif.setTitle(title);
                        objectif.setPriority(priority);
                        objectif.setStatus(status);
                        objectif.setStartDate(startDate);
                        objectif.setEndDate(endDate);

                        ObjectifDAO.updateObjectif(objectif);

                        response.sendRedirect(request.getContextPath() + "/ObjectifServlet");
                    } else {
                        response.sendError(HttpServletResponse.SC_NOT_FOUND, "Objective not found.");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error occurred while updating the objective");
                }
            } else {
                String title = request.getParameter("title");
                String priority = request.getParameter("priority");
                String status = request.getParameter("status");

                String startDateStr = request.getParameter("startDate");
                String endDateStr = request.getParameter("endDate");

                Date startDate = null;
                Date endDate = null;

                try {
                    if (startDateStr != null && !startDateStr.isEmpty()) {
                        startDate = Date.valueOf(startDateStr);
                    }
                    if (endDateStr != null && !endDateStr.isEmpty()) {
                        endDate = Date.valueOf(endDateStr);
                    }

                    Objectif newObjectif = new Objectif(title, priority, status, startDate, endDate, user.getId());
                    ObjectifDAO.addObjectif(newObjectif);

                    response.sendRedirect(request.getContextPath() + "/ObjectifServlet");
                } catch (SQLException e) {
                    e.printStackTrace();
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error occurred while adding the objective");
                }
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/views/login.jsp");
        }
    }
}
